package taller;

public class Medicion {

}
