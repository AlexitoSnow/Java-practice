package taller;

public class Piscina {

}
